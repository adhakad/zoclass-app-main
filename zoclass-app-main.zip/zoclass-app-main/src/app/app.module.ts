import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminAuthInterceptor } from './interceptors/admin-auth.interceptor';
import { TeacherAuthInterceptor } from './interceptors/teacher-auth.interceptor';
import { StudentAuthInterceptor } from './interceptors/student-auth.interceptor';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PortalModule } from '@angular/cdk/portal';
// import { ScrollingModule } from '@angular/cdk/scrolling';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MaterialUiModule } from './material/material-ui/material-ui.module';
import { HttpClientModule ,HTTP_INTERCEPTORS} from '@angular/common/http';
import { RoundProgressModule } from 'angular-svg-round-progressbar';
import { MatMomentDatetimeModule } from '@mat-datetimepicker/moment';
import { MatDatetimepickerModule, MAT_DATETIME_FORMATS } from '@mat-datetimepicker/core';


import { HeaderComponent } from './common/header/header.component';
import { HomeComponent } from './pages/main/home/home.component';
import { TestComponent } from './pages/main/test/test.component';
import { StudyComponent } from './pages/main/study/study.component';
import { NoticeComponent } from './pages/main/notice/notice.component';

import { TestStartComponent } from './pages/main/nested-pages/test-start/test-start.component';
import { SubjectCategoryComponent } from './pages/main/nested-pages/subject-category/subject-category.component';
import { BlogListComponent } from './pages/main/nested-pages/blog-list/blog-list.component';
import { SingleBlogComponent } from './pages/main/nested-pages/single-blog/single-blog.component';
import { TestListComponent } from './pages/main/nested-pages/test-list/test-list.component';
import { TestResultComponent } from './pages/main/nested-pages/test-result/test-result.component';
import { NavbarComponent } from './common/navbar/navbar.component';
import { NgxMatFileInputModule } from '@angular-material-components/file-input';
import { AdminLoginComponent } from './pages/auth/admin-auth/admin-login/admin-login.component';
import { StudentLoginComponent } from './pages/auth/student-auth/student-login/student-login.component';
import { TeacherLoginComponent } from './pages/auth/teacher-auth/teacher-login/teacher-login.component';
import { StudentSignupComponent } from './pages/auth/student-auth/student-signup/student-signup.component';
import { TeacherSignupComponent } from './pages/auth/teacher-auth/teacher-signup/teacher-signup.component';
import { AdminSharedModule } from './pages/admin/admin-shared/admin-shared.module';
import { TeacherSharedModule } from './pages/teacher/teacher-shared/teacher-shared.module';
import { StudentSharedModule } from './pages/student/student-shared/student-shared.module';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    TestComponent,
    StudyComponent,
    NoticeComponent,

    TestStartComponent,
    SubjectCategoryComponent,
    BlogListComponent,
    SingleBlogComponent,
    TestListComponent,
    TestResultComponent,
    NavbarComponent,
    AdminLoginComponent,
    StudentLoginComponent,
    TeacherLoginComponent,
    StudentSignupComponent,
    TeacherSignupComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    RoundProgressModule,
    PortalModule,
    MaterialUiModule,
    MatMomentDatetimeModule,
    MatDatetimepickerModule,
    NgxMatFileInputModule,
    AdminSharedModule,
    TeacherSharedModule,
    StudentSharedModule
  ],
  providers: [
    {provide:HTTP_INTERCEPTORS,useClass:AdminAuthInterceptor,multi:true},
    {provide:HTTP_INTERCEPTORS,useClass:TeacherAuthInterceptor,multi:true},
    {provide:HTTP_INTERCEPTORS,useClass:StudentAuthInterceptor,multi:true},
    {
      provide: MAT_DATETIME_FORMATS,
      useValue: {
        parse: {
          dateInput: 'L',
          monthInput: 'MMMM',
          timeInput: 'LT',
          datetimeInput: 'L LT',
        },
        display: {
          dateInput: 'L',
          monthInput: 'MMMM',
          datetimeInput: 'L LT',
          timeInput: 'LT',
          monthYearLabel: 'MMM YYYY',
          dateA11yLabel: 'LL',
          monthYearA11yLabel: 'MMMM YYYY',
          popupHeaderDateLabel: 'ddd, DD MMM',
        },
      },
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(){
    console.log("app module load")
  }
 }
