export interface AdminLoginData {
    email:String,
    password:String,
}