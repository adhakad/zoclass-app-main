export interface Ads {
    _id:String,
    title:String,
    image:String,
}