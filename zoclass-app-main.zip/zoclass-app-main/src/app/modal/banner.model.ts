export interface Banner {
    _id:String,
    title:String,
    image:String,
}