export interface ClassSubject {
    _id:String,
    class:Number,
    subject:String,
}