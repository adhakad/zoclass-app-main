export interface Class {
    _id:String,
    class:Number
}