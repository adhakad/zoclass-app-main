export interface ClassSubject {
    _id:String,
    class:String,
    subject:String,
}