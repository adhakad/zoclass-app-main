export interface Result {
    _id:String,
    name:  String,
    rollNumber:  Number,
    class:  Number,
    subject:  String,
    marks:  Number,
}