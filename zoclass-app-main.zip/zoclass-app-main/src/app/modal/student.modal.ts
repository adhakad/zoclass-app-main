export interface Student {
    _id:String,
    name:String,
    email:String,
    password:String,
    class:Number,
    rollNumber: Number,
}
export interface StudentLoginData {
    email:String,
    password:String,
}