export interface Subject {
    _id:String,
    subject:String,
    image: String,
}