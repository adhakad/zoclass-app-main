export interface Testimonial {
    _id:String,
    name:String,
    role:String,
    desc:String,
    image:String,
}