    export interface Topper {
        _id:String,
        name:String,
        class:Number,
        percentile:Number,
        year:Number,
        image:String,
    }