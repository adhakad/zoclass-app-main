import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TestResultService } from 'src/app/services/test-result.service';
import { TestService } from 'src/app/services/test.service';

@Component({
  selector: 'app-admin-student-result',
  templateUrl: './admin-student-result.component.html',
  styleUrls: ['./admin-student-result.component.css']
})
export class AdminStudentResultComponent implements OnInit {
  studentResultsInfo:any;
  studentInfo:any;
  testInfo:any;
  testFilterInfo:any;
  constructor(public activatedRoute:ActivatedRoute,private testResultService:TestResultService,private testService:TestService) { }

  ngOnInit(): void {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    let cls = this.activatedRoute.snapshot.paramMap.get('cls');
    this.testByClass(cls);
    this.resultsByStudent(id);
  }
  testByClass(cls:any){
    this.testService.testByClass(cls).subscribe((res:any) => {
      this.testInfo = res.testList;
    })
  }
  resultsByStudent(id:any){
    this.testResultService.resultsByStudent(id).subscribe((res:any) => {
      if(res){
        this.studentInfo = res.studentInfo;
        this.studentResultsInfo = res.studentResults;
        this.testFilterInfo = this.testInfo.filter(({_id:id1}:any) => this.studentResultsInfo.some(({testId:id2}:any) => id1 ===id2));
      }
    })
  }
}
