import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-pages',
  templateUrl: './notification-pages.component.html',
  styleUrls: ['./notification-pages.component.css']
})
export class NotificationPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
